// ═══════════════════════════════════════════════════════════════
// Firebase Cloud Functions — Aile Bütçe Pro Bildirim Sunucusu
// ═══════════════════════════════════════════════════════════════
// Kurulum:
//   npm install -g firebase-tools
//   firebase login
//   firebase init functions   (mevcut projeyi seç: ailebutce-fbabc)
//   Bu dosyayı functions/index.js olarak koy
//   firebase deploy --only functions

const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();
const messaging = admin.messaging();

// ───────────────────────────────────────────────
// YARDIMCI: Cihaza FCM bildirimi gönder
// ───────────────────────────────────────────────
async function sendToDevice(token, title, body, data = {}) {
  try {
    await messaging.send({
      token,
      notification: { title, body },
      android: {
        priority: "high",
        notification: {
          channelId: "aile-butce",
          sound: "default",
          icon: "ic_notification",
          color: "#FFD84D",
          clickAction: "FLUTTER_NOTIFICATION_CLICK"
        }
      },
      data: { ...data, click_action: "FLUTTER_NOTIFICATION_CLICK" }
    });
    console.log(`✅ Bildirim gönderildi → ${token.slice(0, 20)}...`);
  } catch (e) {
    console.error(`❌ Bildirim gönderilemedi: ${e.message}`);
    // Geçersiz token'ı temizle
    if (e.code === "messaging/registration-token-not-registered") {
      await db.collection("fcmTokens").where("token", "==", token).get()
        .then(snap => snap.forEach(d => d.ref.delete()));
    }
  }
}

// ───────────────────────────────────────────────
// TÜM CİHAZLARA GÖNDER (aile üyeleri)
// ───────────────────────────────────────────────
async function sendToAll(title, body, excludeDeviceId = null, data = {}) {
  const snap = await db.collection("fcmTokens").get();
  const sends = [];
  snap.forEach(doc => {
    const d = doc.data();
    if (excludeDeviceId && d.deviceId === excludeDeviceId) return;
    if (d.token) sends.push(sendToDevice(d.token, title, body, data));
  });
  await Promise.all(sends);
}

// ───────────────────────────────────────────────
// TETİKLEYİCİ 1: Firestore'da işlem değişince
// Bir aile üyesi kayıt eklediğinde diğerine bildir
// ───────────────────────────────────────────────
exports.onBudgetUpdate = functions.firestore
  .document("sharedData/main")
  .onUpdate(async (change, context) => {
    const before = change.before.data();
    const after = change.after.data();

    // Değişiklik yapan cihazı bul
    const byDevice = after.lastBy;
    const byName = after.lastName || "Bir aile üyesi";
    const action = after.lastAction || "Yeni kayıt";

    // Sadece gerçek değişiklikte bildir
    if (before.lastAt === after.lastAt) return null;

    // Diğer cihazlara bildirim gönder
    await sendToAll(
      "💰 Aile Bütçe Güncellendi",
      `${byName}: ${action}`,
      byDevice,
      { page: "records" }
    );

    // Günlük limit kontrolü
    const today = new Date().toISOString().slice(0, 10);
    const transactions = after.transactions || [];
    const limit = after.limit || 500;

    const dailyExp = transactions
      .filter(t => t.type === "expense" && t.date === today)
      .reduce((s, t) => s + Number(t.amount || 0), 0);

    if (dailyExp > limit) {
      // Tüm cihazlara limit uyarısı
      const snap = await db.collection("fcmTokens").get();
      for (const doc of snap.docs) {
        const tokenData = doc.data();
        const settings = tokenData.notifSettings || {};
        if (settings.limit === false) continue; // Bu cihaz kapatmış
        await sendToDevice(
          tokenData.token,
          "⚠️ Günlük Limit Aşıldı!",
          `Bugün ${Math.round(dailyExp).toLocaleString("tr-TR")} TL harcandı. Limit: ${Math.round(limit).toLocaleString("tr-TR")} TL`,
          { page: "charts" }
        );
      }
    }

    // Aylık hedef kontrolü
    const now = new Date();
    const thisYear = now.getFullYear();
    const thisMonth = now.getMonth();
    const monthlyTarget = after.monthlyTarget || 15000;

    const monthExp = transactions
      .filter(t => {
        if (t.type !== "expense") return false;
        const d = new Date(t.date + "T00:00:00");
        return d.getFullYear() === thisYear && d.getMonth() === thisMonth;
      })
      .reduce((s, t) => s + Number(t.amount || 0), 0);

    if (monthExp > monthlyTarget) {
      const snap2 = await db.collection("fcmTokens").get();
      for (const doc of snap2.docs) {
        const tokenData = doc.data();
        const settings = tokenData.notifSettings || {};
        if (settings.monthly === false) continue;
        await sendToDevice(
          tokenData.token,
          "📊 Aylık Hedef Aşıldı!",
          `Bu ay ${Math.round(monthExp).toLocaleString("tr-TR")} TL harcandı. Hedef: ${Math.round(monthlyTarget).toLocaleString("tr-TR")} TL`,
          { page: "analytics" }
        );
      }
    }

    return null;
  });

// ───────────────────────────────────────────────
// TETİKLEYİCİ 2: Her sabah 08:00 sabah özeti
// (Türkiye saati = UTC+3, yani UTC 05:00)
// ───────────────────────────────────────────────
exports.morningReminder = functions.pubsub
  .schedule("0 5 * * *")  // UTC 05:00 = Türkiye 08:00
  .timeZone("Europe/Istanbul")
  .onRun(async () => {
    console.log("🌅 Sabah hatırlatması gönderiliyor...");

    const budgetSnap = await db.doc("sharedData/main").get();
    if (!budgetSnap.exists) return null;

    const budgetData = budgetSnap.data();
    const today = new Date().toISOString().slice(0, 10);
    const limit = budgetData.limit || 500;

    const dailyExp = (budgetData.transactions || [])
      .filter(t => t.type === "expense" && t.date === today)
      .reduce((s, t) => s + Number(t.amount || 0), 0);

    const remaining = limit - dailyExp;
    const msg = dailyExp > 0
      ? `Bugün ${Math.round(dailyExp).toLocaleString("tr-TR")} TL harcandı. Kalan limit: ${Math.round(Math.max(0, remaining)).toLocaleString("tr-TR")} TL`
      : "Günaydın! Harcamalarını takip etmeyi unutma 💪";

    // Sabah bildirimi aktif olan cihazlara gönder
    const snap = await db.collection("fcmTokens").get();
    for (const doc of snap.docs) {
      const tokenData = doc.data();
      const settings = tokenData.notifSettings || {};
      if (settings.morning === false) continue;
      await sendToDevice(
        tokenData.token,
        "🌅 Aile Bütçe — Günaydın!",
        msg,
        { page: "charts" }
      );
    }

    return null;
  });

// ───────────────────────────────────────────────
// TETİKLEYİCİ 3: Özel saat bildirimi
// Her saat başı çalışır, o saati tercih edenlere gönderir
// ───────────────────────────────────────────────
exports.customTimeReminder = functions.pubsub
  .schedule("0 * * * *")  // Her saat başı
  .timeZone("Europe/Istanbul")
  .onRun(async () => {
    const nowHour = new Date(new Date().toLocaleString("en-US", { timeZone: "Europe/Istanbul" })).getHours();
    const nowMinute = new Date(new Date().toLocaleString("en-US", { timeZone: "Europe/Istanbul" })).getMinutes();

    const snap = await db.collection("fcmTokens").get();
    for (const doc of snap.docs) {
      const tokenData = doc.data();
      const settings = tokenData.notifSettings || {};
      if (!settings.custom || !settings.customTime) continue;

      const [h, min] = settings.customTime.split(":").map(Number);
      if (h === nowHour && Math.abs(min - nowMinute) <= 5) {
        await sendToDevice(
          tokenData.token,
          "⏰ Aile Bütçe Hatırlatması",
          "Bugünkü harcamalarını girmek ister misin?",
          { page: "records" }
        );
      }
    }

    return null;
  });
