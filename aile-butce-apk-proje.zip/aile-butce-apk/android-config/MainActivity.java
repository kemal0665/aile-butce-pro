// ═══════════════════════════════════════════════════════════════
// android/app/src/main/java/com/ailebutce/pro/MainActivity.java
// ═══════════════════════════════════════════════════════════════
// Bu dosyayı Capacitor'ın oluşturduğu MainActivity.java ile DEĞİŞTİR.
// "npx cap add android" yaptıktan sonra bu adrese koy.

package com.ailebutce.pro;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Ana bildirim kanalı
            NotificationChannel channel = new NotificationChannel(
                "aile-butce",
                "Aile Bütçe Bildirimleri",
                NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Limit aşımı ve günlük hatırlatmalar");
            channel.enableVibration(true);
            channel.setShowBadge(true);

            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
}
