# 📱 Aile Bütçe Pro — APK Kurulum Rehberi
## Kapalıyken Bildirim Gönderen Gerçek Android APK

---

## 📋 GENEL MİMARİ

```
Telefon (APK)          Firebase               Sunucu
┌─────────────┐        ┌──────────┐           ┌─────────────────┐
│ Capacitor   │◄──────►│ Firestore│◄──────────│ Cloud Functions │
│ WebView     │        │ FCM      │           │ (Otomatik tetik)│
│ index.html  │        └──────────┘           └─────────────────┘
└─────────────┘
      ▲
      │ Bildirim (kapalıyken de!)
      ▼
┌─────────────┐
│  Android    │
│  Sistem     │
│  Bildirimi  │
└─────────────┘
```

**Uygulama kapalıyken bildirimler nasıl çalışır?**
Firebase Cloud Functions bir değişiklik algıladığında (yeni harcama, limit aşımı vs.) 
FCM üzerinden telefona "push" mesajı gönderir. Android bu mesajı uygulama kapalı 
olsa bile sistem seviyesinde alır ve bildirim gösterir.

---

## 🛠️ ADIM 1 — Gerekli Araçları Kur

### A) Node.js (v18+)
```bash
# https://nodejs.org adresinden indir
node --version   # v18+ olmalı
```

### B) Java Development Kit (JDK 17)
```bash
# https://adoptium.net adresinden Temurin JDK 17 indir
java --version   # 17 olmalı
```

### C) Android Studio
```
https://developer.android.com/studio adresinden indir
Kurulum sırasında şunları seç:
  ✅ Android SDK
  ✅ Android SDK Platform (API 34)
  ✅ Android Virtual Device
```

### D) Ortam Değişkenleri (Windows)
```
Sistem Özellikleri → Gelişmiş → Ortam Değişkenleri
ANDROID_HOME = C:\Users\KULLANICI\AppData\Local\Android\Sdk
PATH'e ekle: %ANDROID_HOME%\platform-tools
PATH'e ekle: %ANDROID_HOME%\tools
```

---

## 🔥 ADIM 2 — Firebase FCM Kur

### A) Firebase Console'a git → ailebutce-fbabc projeni aç
```
https://console.firebase.google.com
```

### B) Proje Ayarları → Cloud Messaging sekmesi
- **Server key** not al (Cloud Functions için gerekir)
- **google-services.json** indir (Android için)

### C) google-services.json'u koy
```
Bu dosyayı şuraya yerleştir:
android/app/google-services.json
```

### D) Firebase'de Firestore Kuralları
Firebase Console → Firestore → Kurallar:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /sharedData/{doc} {
      allow read, write: if true;
    }
    match /fcmTokens/{deviceId} {
      allow read, write: if true;
    }
  }
}
```

---

## 📦 ADIM 3 — Capacitor Projesi Oluştur

```bash
# 1. Proje klasörüne git
cd aile-butce-apk

# 2. Bağımlılıkları yükle
npm install

# 3. Android platformu ekle
npx cap add android

# 4. www/index.html ile android'i senkronize et
npx cap sync android
```

---

## 🔧 ADIM 4 — Android Yapılandırması

### A) google-services.json kopyala
```bash
# İndirdiğin google-services.json'u buraya koy:
cp google-services.json android/app/google-services.json
```

### B) MainActivity.java'yı değiştir
```bash
# android-config/MainActivity.java içeriğini şuraya kopyala:
android/app/src/main/java/com/ailebutce/pro/MainActivity.java
```

### C) AndroidManifest.xml'e izinleri ekle
```bash
# android-config/AndroidManifest-patch.xml dosyasındaki 
# izinleri AndroidManifest.xml'e ekle:
android/app/src/main/AndroidManifest.xml
```

### D) android/app/build.gradle'e Firebase ekle
```groovy
// Dosyanın EN ALTINA ekle:
apply plugin: 'com.google.gms.google-services'

// dependencies {} bloğuna ekle:
implementation platform('com.google.firebase:firebase-bom:33.0.0')
implementation 'com.google.firebase:firebase-messaging'
```

### E) android/build.gradle'e ekle
```groovy
// dependencies {} bloğuna ekle:
classpath 'com.google.gms:google-services:4.4.1'
```

---

## ☁️ ADIM 5 — Cloud Functions Deploy Et

```bash
# Firebase CLI kur
npm install -g firebase-tools
firebase login

# firebase-functions klasörüne git
cd firebase-functions
npm install

# Deploy et (sunucu bildirim kodunu yükle)
firebase deploy --only functions --project ailebutce-fbabc
```

**Deploy başarılıysa şu Functions aktif olur:**
- `onBudgetUpdate` → Harcama eklenince diğer cihaza bildir
- `morningReminder` → Her sabah 08:00 bildirim (cron job)
- `customTimeReminder` → Seçilen saatte bildirim (cron job)

---

## 🏗️ ADIM 6 — APK Derle

### Android Studio ile:
```bash
npx cap open android
```
Android Studio açılır → Build → Build APK(s)
APK şurada oluşur: `android/app/build/outputs/apk/debug/app-debug.apk`

### Komut satırıyla:
```bash
cd android
./gradlew assembleDebug    # debug APK
./gradlew assembleRelease  # yayın APK (imzalama gerekir)
```

---

## 📲 ADIM 7 — Telefona Yükle

```bash
# USB ile bağlı telefona yükle
adb install android/app/build/outputs/apk/debug/app-debug.apk

# Ya da APK dosyasını telefona kopyala → yükle
```

**Telefon ayarları:**
- Ayarlar → Geliştirici Seçenekleri → USB Hata Ayıklama: AÇIK
- Ayarlar → Güvenlik → Bilinmeyen Kaynaklardan Yükleme: İZİN VER

---

## ✅ ADIM 8 — Test Et

1. APK'yı aç → **Profil** sekmesine git
2. **"Bildirimleri Etkinleştir"** butonuna bas
3. İzin ver → "✅ Bildirimler Aktif" yazısını gör
4. **Uygulamayı tamamen kapat** (görev yöneticisinden kaldır)
5. Başka bir telefon/tarayıcıda uygulamayı aç → harcama ekle
6. **Kapalı telefonunda bildirim gelecek!** 🎉

---

## 🧪 SORUN GİDERME

### "FCM Token alınamıyor"
- google-services.json doğru yerde mi? → `android/app/google-services.json`
- İnternet bağlantısı var mı?
- Firebase projesinde Cloud Messaging aktif mi?

### "Cloud Functions deploy edilemiyor"
- Firebase plan'ı Blaze (kullandıkça öde) mi? Cron job için gerekli
- `firebase login` yapıldı mı?

### "Bildirimler gelmiyor"
- Telefon pil optimizasyonu uygulamayı kapatıyor olabilir
- Ayarlar → Uygulamalar → Aile Bütçe → Pil → "Kısıtlama Yok" seç
- MIUI/EMUI için: Otomatik Başlatma izni ver

### "Gradle build hatası"
```bash
cd android
./gradlew clean
./gradlew assembleDebug
```

---

## 💡 BİLDİRİM AKIŞI ÖZET

```
Kullanıcı gider ekler
        │
        ▼
Firestore güncellenir
        │
        ▼
Cloud Function tetiklenir (onBudgetUpdate)
        │
        ├─► Limit aşıldı mı? ──► FCM push gönder → Telefon bildirimi ✅
        │
        └─► Aylık hedef aşıldı mı? ──► FCM push gönder → Telefon bildirimi ✅

Her sabah 08:00 (Türkiye saati)
        │
        ▼
morningReminder Cloud Function
        │
        └─► Tüm cihazlara sabah özeti ──► Telefon bildirimi ✅

Seçilen özel saat (her saat kontrol edilir)
        │
        ▼
customTimeReminder Cloud Function
        │
        └─► İlgili cihaza hatırlatma ──► Telefon bildirimi ✅
```

---

## 📁 DOSYA YAPISI

```
aile-butce-apk/
├── www/
│   └── index.html              ← Capacitor bildirim kodu eklenmiş uygulama
├── capacitor.config.json       ← Capacitor yapılandırması
├── package.json                ← npm bağımlılıkları
├── android-config/
│   ├── MainActivity.java       ← Bildirim kanalı oluşturan Android kodu
│   └── AndroidManifest-patch.xml ← Gerekli Android izinleri
└── firebase-functions/
    ├── index.js                ← Sunucu bildirim mantığı (Cloud Functions)
    └── package.json            ← Functions bağımlılıkları
```

---

*Herhangi bir adımda takılırsan, hata mesajını paylaş — yardımcı olabilirim.*
